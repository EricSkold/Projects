# lab-2-graphs-and-transport-networks-skold-nilsson-1
lab-2-graphs-and-transport-networks-skold-nilsson-1 created by GitHub Classroom

We have implemented our dijkstra function with the native implementation, not using networkx. 
