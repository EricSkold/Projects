# TODO: mock-up to be replaced by your file from Lab 2

class WeightedGraph:
    pass


def dijkstra():
    pass
